package test;

import gui.GraphicalMap;

public class testsBeasts {
	public static void main(String[] args) throws InterruptedException {
		
		
			GraphicalMap map = new GraphicalMap();
			


	
	}
}
