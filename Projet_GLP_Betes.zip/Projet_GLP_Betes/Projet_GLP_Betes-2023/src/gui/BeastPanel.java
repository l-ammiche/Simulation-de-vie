package gui;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;

import data.Beast;
import data.Biome;

public class BeastPanel extends JPanel {
	
	private static final long serialVersionUID = -3253071850484805893L;
	
	private Beast beast;
	private Image beastImage;
	
	public BeastPanel() {
		beast = new Beast(beast, beast);
		beastImage = null;
	}
	
	public BeastPanel(Beast newBeast) {
		beast = newBeast;
		beastImage = null;
	}
	
	public BeastPanel(Beast newBeast, Biome newBiome) {
		beast = newBeast;
		beastImage = null;
	}
	
	public void setBeast(Beast beastSet) {
		beast = beastSet;
	}
	
	
	
	public void setBeastImage() {
		String imagePath = null;
		if (beast.canMove()) {
			imagePath = "assets/beasts/";
			imagePath += beast.getSexe() + "_";
			imagePath += beast.getBiome().getBiomeType() + "_";
			imagePath += beast.getOrientation() + ".png";
			beastImage = Toolkit.getDefaultToolkit().getImage(imagePath);
		} else {
			if (beast.isFighting()) imagePath = "assets/images/fight.png";
			else if (beast.isCopulating()) imagePath = "assets/images/reproduction.png";
			else if (beast.isDead()) imagePath = "assets/images/death-icon.png";
			beastImage = Toolkit.getDefaultToolkit().getImage(imagePath);
		}
	}
	
	
	
	public void setBeastImage(Image image) {
		beastImage = image;
	}
	
	public Beast getBeast() {
		return beast;
	}
	
	public Image getBeastImage() {
		return beastImage;
	}
	
	
	
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (beastImage != null) {
			int x = (getWidth() - beastImage.getWidth(null)) / 2;
			int y = (getHeight() - beastImage.getHeight(null)) / 2;
			g.drawImage(beastImage, x, y, null);
		}
	}
}
