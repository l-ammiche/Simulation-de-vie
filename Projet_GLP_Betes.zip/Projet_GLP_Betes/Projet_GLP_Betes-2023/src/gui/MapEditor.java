package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;

import data.Biome;

public class MapEditor extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int CELL_SIZE = 10;

    private int rows;
    private int columns;
    private Biome[][] map;
    private Map<Point, Biome> changes;
    private Biome selectedBiome;

    public MapEditor(int rows, int columns, Biome[][] map) {
        this.rows = rows;
        this.columns = columns;
        this.map = map;
        this.changes = new HashMap<>();
        this.selectedBiome = Biome.PLAINS;

        setPreferredSize(new Dimension(columns * CELL_SIZE, rows * CELL_SIZE));
        setBackground(Color.WHITE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x = e.getX() / CELL_SIZE;
                int y = e.getY() / CELL_SIZE;
                Point cell = new Point(x, y);
                if (x >= 0 && x < columns && y >= 0 && y < rows) {
                    changes.put(cell, selectedBiome);
                    repaint();
                }
            }
        });
    }

    public void setSelectedBiome(Biome biome) {
        this.selectedBiome = biome;
    }

    public void applyChanges() {
        for (Map.Entry<Point, Biome> entry : changes.entrySet()) {
            Point cell = entry.getKey();
            Biome biome = entry.getValue();
            map[cell.y][cell.x] = biome;
        }
        changes.clear();
    }

    public void cancelChanges() {
        changes.clear();
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                Biome biome = map[row][col];
                g.setColor(biome.getColor());
                g.fillRect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE);
            }
        }

        g.setColor(selectedBiome.getColor());
        g.drawRect(0, 0, columns * CELL_SIZE - 1, rows * CELL_SIZE - 1);

        for (Map.Entry<Point, Biome> entry : changes.entrySet()) {
            Point cell = entry.getKey();
            Biome biome = entry.getValue();
            g.setColor(biome.getColor());
            g.fillRect(cell.x * CELL_SIZE, cell.y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
        }
    }

}
