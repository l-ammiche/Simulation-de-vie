package gui;

import data.Beast;
import gui.JPanelInfos;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import core.CreerJournal;

public class AfficherJournal
extends JFrame {
    private static final long serialVersionUID = 1L;
    protected Beast bete;
    protected JPanel jpanelInfos;
    protected JScrollPane jp;
	private Beast beast;

    public AfficherJournal(Beast bete) {
        this.setTitle("Journal de la Bete : " + bete.getId());
        this.setSize(400, 430);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(2);
        this.setAlwaysOnTop(true);
        this.setVisible(true);
        this.beast = bete;
        new CreerJournal(bete);
        //String journal = bete.getJournal().getJournal();
        //this.jpanelInfos = new JPanelInfos(journal);
        this.jpanelInfos.setPreferredSize(new Dimension(400, 2000));
        this.jp = new JScrollPane(this.jpanelInfos);
        this.jp.setVerticalScrollBarPolicy(22);
        this.jp.setHorizontalScrollBarPolicy(32);
        this.jp.setBounds(10, 10, 600, 2000);
        this.getContentPane().add(this.jp);
    }
}

