package gui;

public class JPanelInfos {

}
