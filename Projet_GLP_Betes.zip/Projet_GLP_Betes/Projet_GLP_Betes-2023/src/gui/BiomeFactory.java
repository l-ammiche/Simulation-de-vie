package gui;

import data.Biome;

public class BiomeFactory {
    
    public Biome createBiome(String biomeType) {
        switch(biomeType) {
            case "Tropical":
                return new Biome();
            case "Temperate":
                return new Biome();
            case "Polar":
                return new Biome();
            default:
                throw new IllegalArgumentException("Invalid biome type: " + biomeType);
        }
    }

	public Biome[] getAvailableBiomes() {
		return null;
	}

	public void addBiome(Biome selectedBiome, int percentage) {
		
	}
}
