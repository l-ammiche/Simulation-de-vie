package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.JPanel;
import data.*;

public class MapPanel {
	
	private TilePanel[][] tilesPanel;
	private ArrayList<BeastPanel> beastPanel;
	private ArrayList<Food> foodPanel;
	
	/**
	 * Constructeur par défaut de la classe MapPanel.
	 * Initialise les tableaux et les listes nécessaires.
	 */
	public MapPanel() {
		tilesPanel = new TilePanel[Map_Settings.MAP_WIDTH][Map_Settings.MAP_LENGTH];
		beastPanel = new ArrayList<BeastPanel>();
		setFoodPanel(new ArrayList<Food>());
	}
	
	/**
	 * Constructeur de la classe MapPanel avec une largeur et une longueur spécifiées.
	 * Initialise les tableaux et les listes nécessaires avec les dimensions fournies.
	 * 
	 * @param width La largeur de la carte
	 * @param length La longueur de la carte
	 */
	public MapPanel(int width, int length) {
		tilesPanel = new TilePanel[width][length];
		beastPanel = new ArrayList<BeastPanel>();
		setFoodPanel(new ArrayList<Food>());
	}
	
	/**
	 * Définit le panneau de tuile à une position donnée avec le numéro du biome spécifié.
	 * 
	 * @param absciss L'abscisse de la tuile
	 * @param ordinate L'ordonnée de la tuile
	 * @param biomeNumber Le numéro du biome
	 */
	public void setTilePanel(int absciss, int ordinate, int biomeNumber) {
		tilesPanel[absciss][ordinate] = new TilePanel(biomeNumber);
	}
	
	/**
	 * Définit le panneau de tuile à une position donnée avec le numéro du biome et l'obstacle spécifiés.
	 * 
	 * @param absciss L'abscisse de la tuile
	 * @param ordinate L'ordonnée de la tuile
	 * @param biomeNumber Le numéro du biome
	 * @param obstacle Indique si la tuile est un obstacle
	 */
	public void setTilePanel(int absciss, int ordinate, int biomeNumber, boolean obstacle) {
		tilesPanel[absciss][ordinate] = new TilePanel(biomeNumber, obstacle);
	}
	
	/**
	 * Retourne le tableau de panneaux de tuiles.
	 * 
	 * @return Le tableau de panneaux de tuiles
	 */
	public TilePanel[][] getTilesPanel() {
		return tilesPanel;
	}
	
	/**
	 * Retourne le panneau de tuile à la position donnée.
	 * 
	 * @param absciss L'abscisse de la tuile
	 * @param ordinate L'ordonnée de la tuile
	 * @return Le panneau de tuile à la position donnée
	 */
	public TilePanel getTilePanel(int absciss, int ordinate) {
		return tilesPanel[absciss][ordinate];
	}
	
	/**
	 * Retourne la tuile à la position donnée.
	 * 
	 * @param absciss L'abscisse de la tuile
	 * @param ordinate L'ordonnée de la tuile
	 * @return La tuile à la position donnée
	 */
	public Tile getTile(int absciss, int ordinate) {
		return tilesPanel[absciss][ordinate].getTile();
	}
	
	/**
	 * Retourne la liste des panneaux de bêtes.
	 * 
	 * @return La liste des panneaux de bêtes
	 */
	public ArrayList<BeastPanel> getBeastPanel() {
		return beastPanel;
	}
	
	/**
	 * Retourne le panneau de bête avec le numéro de bête spécifié.
	 * 
	 * @param beastNumber Le numéro de la bête
	 * @return Le panneau de bête avec le numéro de bête spécifié
	 */
	public BeastPanel getBeastPanel(int beastNumber) {
		return beastPanel.get(beastNumber);
	}
	
	/**
	 * Retourne la bête avec le numéro de bête spécifié.
	 * 
	 * @param beastNumber Le numéro de la bête
	 * @return La bête avec le numéro de bête spécifié
	 */
	public Beast getBeast(int beastNumber) {
		return beastPanel.get(beastNumber).getBeast();
	}

	/**
	 * Retourne la liste des panneaux de nourriture.
	 * 
	 * @return La liste des panneaux de nourriture
	 */
	public ArrayList<Food> getFoodPanel() {
		return foodPanel;
	}

	/**
	 * Définit la liste des panneaux de nourriture.
	 * 
	 * @param foodPanel La liste des panneaux de nourriture
	 */
	public void setFoodPanel(ArrayList<Food> foodPanel) {
		this.foodPanel = foodPanel;
	}
}

