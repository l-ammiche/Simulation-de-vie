package gui;

import javax.swing.*;

import data.Biome;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FactoryPanelEditor extends JPanel implements ActionListener {

    private JComboBox<String> biomeSelector;
    private JTextField percentageField;
    private JButton addButton;
    private JLabel errorLabel;
    private Biome[] biomes;
    private BiomeFactory factory;

    public FactoryPanelEditor(BiomeFactory factory) {
        this.factory = factory;
        this.biomes = factory.getAvailableBiomes();

        setLayout(new GridLayout(0, 2, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel biomeLabel = new JLabel("Biome:");
        add(biomeLabel);

        String[] biomeNames = new String[biomes.length];
        for (int i = 0; i < biomes.length; i++) {
            biomeNames[i] = (String) biomes[i].getName();
        }

        biomeSelector = new JComboBox<>(biomeNames);
        add(biomeSelector);

        JLabel percentageLabel = new JLabel("Percentage:");
        add(percentageLabel);

        percentageField = new JTextField();
        add(percentageField);

        addButton = new JButton("Add");
        addButton.addActionListener(this);
        add(addButton);

        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        add(errorLabel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            try {
                String biomeName = (String) biomeSelector.getSelectedItem();
                Biome selectedBiome = null;
                for (Biome biome : biomes) {
                    if (biome.getName().equals(biomeName)) {
                        selectedBiome = biome;
                        break;
                    }
                }

                int percentage = Integer.parseInt(percentageField.getText());

                factory.addBiome(selectedBiome, percentage);

                errorLabel.setText("");
                percentageField.setText("");
            } catch (NumberFormatException ex) {
                errorLabel.setText("Invalid percentage");
            } catch (IllegalArgumentException ex) {
                errorLabel.setText(ex.getMessage());
            }
        }
    }
}
