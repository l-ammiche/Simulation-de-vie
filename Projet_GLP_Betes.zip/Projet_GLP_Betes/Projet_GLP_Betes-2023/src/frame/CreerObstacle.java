package frame;


import data.Tile;
import gui.MapPanel;
/*
public class CreerObstacle {
    public CreerObstacle(Tile grille) {
        int taille = grille.setLocation();
        int i = 0;
        while (i < grille.getTailleGrille() / 2) {
            int positionIDansGrille = this.randomWithRange(0, taille - 1);
            int positionJDansGrille = this.randomWithRange(0, taille - 1);
            boolean obstacle = true;
            Tile caseObstacleCreer = grille.getTile(positionIDansGrille, positionJDansGrille);
            if (caseObstacleCreer.getBete1() == null && caseObstacleCreer.getLocation() == null && caseObstacleCreer.containsFood() == null && !caseObstacleCreer.getTile()) {
                caseObstacleCreer.setObstacle(obstacle);
            }
            ++i;
        }
    }

    public int randomWithRange(int min, int max) {
        int range = max - min + 1;
        return (int)(Math.random() * (double)range) + min;
    }
}*/

