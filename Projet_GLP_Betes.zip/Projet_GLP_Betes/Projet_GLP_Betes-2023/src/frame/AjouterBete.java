package frame;


/*
import chrono.Chronometer;
import data.Attack;
import data.Beast;
import data.Defense;
import data.bete.Element;
import data.bete.EnvironnementFort;
import data.bete.Journal;
import data.Tile;
import gui.MapPanel;
import log.LoggerUtility;
import core.CreerAttaque;
import core.CreerDefense;
import core.CreerElement;
import org.apache.log4j.Logger;

public class AjouterBete {
    private Tile grille;
    private static Logger logger = LoggerUtility.getLogger(AjouterBete.class, "text");

    public AjouterBete(MapPanel grille, Tile caseDeLaBete, Chronometer chronometer) {
        this.tile = Tile;
    }

    public Bete creerLaBete(MapPanel grille, Tile caseDeLaBete, Chronometer chronometer, int i, int j) {
        int idNouvelleBete = this.trouverIdNouvelleBete();
        int sexeRandom = this.randomWithRange(0, 1);
        String sexe = sexeRandom == 0 ? "femelle" : "male";
        CreerAttaque ca = new CreerAttaque();
        Attaque attaque = ca.creerAttaque();
        CreerDefense cd = new CreerDefense();
        Defense defense = cd.creerDefense();
        CreerElement elt = new CreerElement();
        Element defenseSpecial = elt.creerElement();
        int positionIGrille = i;
        int positionJGrille = j;
        String environnement = caseDeLaBete.getEnvironnement().getNomEnvironnement();
        EnvironnementFort environementFort = new EnvironnementFort(environnement);
        String journale = "";
        Journal journal = new Journal(journale);
        int coordX = caseDeLaBete.getOrdinate();
        int coordY = caseDeLaBete.getAbsciss();
        Beast beteCree = new Beast(idNouvelleBete, sexe, attaque, defense, defenseSpecial, environementFort, new Stamina(), coordX, coordY, journal);
        beteCree.setHeureNaissance(chronometer);
        logger.info((Object)(";" + beteCree.getId() + ";" + "Creation;" + beteCree.getSexe() + ";"));
        return beteCree;
    }

    public int trouverIdNouvelleBete() {
        int id = this.grille.getNbBeteDepuisLeDebut() + 1;
        this.grille.setNbBeteDepuisLeDebut(id);
        return id;
    }

    public int randomWithRange(int min, int max) {
        int range = max - min + 1;
        return (int)(Math.random() * (double)range) + min;
    }
}
*/
