package frame;

// classe de test 
/*
import chrono.Chronometer;
import data.Attack;
import data.Beast;
import data.Defense;
import data.bete.EnvironnementFort;
import data.bete.Journal;
import data.Tile;
import gui.MapPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import log.LoggerUtility;
import moteur.AjouterBete;
import org.apache.log4j.Logger;

public class AddBeast
extends JFrame {
    private static final long serialVersionUID = 1L;
    private static Logger logger = LoggerUtility.getLogger(AjouterBete.class, "text");
    protected MapPanel grille;
    protected Tile caseDeLaBete;
    protected Chronometer chronometer;
    protected JPanel output;
    protected String resultSexeBete;
    protected int idNouvelleBete;
    protected String sexeBeteType;
    protected String naissanceBeteH;
    protected int energieBeteNb;
    protected int niveauAttaqueNb;
    protected int niveauDefenseNb;
    protected String defenseSpeNb;
    protected String environnementFortVal;
    protected int i;
    protected int j;
    protected JButton creerBete = new JButton("Creer la Bete");

    public AddBeast(JPanel fenetreGrille, MapPanel grille, Tile caseDeLaBete, Chronometer chronometer, int i, int j) {
        this.setTitle("Creation de la Bete");
        this.setSize(400, 430);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(2);
        this.setAlwaysOnTop(true);
        this.setVisible(true);
        this.output = fenetreGrille;
        this.grille = grille;
        this.caseDeLaBete = caseDeLaBete;
        this.chronometer = chronometer;
        this.i = i;
        this.j = j;
        JPanel panel = new JPanel();
        panel.setLayout(null);
        JLabel sexe = new JLabel("Bete de sexe :");
        sexe.setBounds(20, 20, 90, 30);
        String[] sexeList = new String[]{"male", "femelle"};
        JComboBox<String> sexeBete = new JComboBox<String>(sexeList);
        sexeBete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox)e.getSource();
                AddBeast.this.sexeBeteType = (String)cb.getSelectedItem();
            }
        });
        sexeBete.setBounds(110, 20, 100, 30);
        JLabel energie = new JLabel("Energie de la Bete :");
        energie.setBounds(20, 60, 120, 30);
        final JSpinner energieNb = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
        energieNb.setBounds(140, 60, 100, 30);
        ChangeListener listener = new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent e) {
                int valueNb;
                String value = energieNb.getValue().toString();
                AddBeast.this.energieBeteNb = valueNb = Integer.parseInt(value);
            }
        };
        energieNb.addChangeListener(listener);
        JLabel attaque = new JLabel("Attaque de la Bete :");
        attaque.setBounds(20, 100, 120, 30);
        final JSpinner attaqueNb = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
        attaqueNb.setBounds(140, 100, 100, 30);
        ChangeListener listener1 = new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent e) {
                int valueNb1;
                String value1 = attaqueNb.getValue().toString();
                AddBeast.this.niveauAttaqueNb = valueNb1 = Integer.parseInt(value1);
            }
        };
        attaqueNb.addChangeListener(listener1);
        JLabel defense = new JLabel("Defense de la Bete :");
        defense.setBounds(20, 140, 120, 30);
        final JSpinner defenseNb = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
        defenseNb.setBounds(140, 140, 100, 30);
        ChangeListener listener2 = new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent e) {
                int valueNb2;
                String value2 = defenseNb.getValue().toString();
                AddBeast.this.niveauDefenseNb = valueNb2 = Integer.parseInt(value2);
            }
        };
        defenseNb.addChangeListener(listener2);
        JLabel defenseSpe = new JLabel("Defense Sp\u00e9ciale de la Bete :");
        defenseSpe.setBounds(20, 180, 170, 30);
        String[] defenseSpeList = new String[]{"Feu", "Eau", "Plante", "Vol"};
        JComboBox<String> defenseSpeEl = new JComboBox<String>(defenseSpeList);
        defenseSpeEl.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox)e.getSource();
                AddBeast.this.defenseSpeNb = (String)cb.getSelectedItem();
            }
        });
        defenseSpeEl.setBounds(190, 180, 100, 30);
        JLabel environementFort = new JLabel("Environnement Fort de la Bete :");
        environementFort.setBounds(20, 220, 180, 30);
        String[] environementFortList = new String[]{"commun", "desert", "banquise", "foret", "montagne"};
        JComboBox<String> environementFortEl = new JComboBox<String>(environementFortList);
        environementFortEl.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox)e.getSource();
                AddBeast.this.environnementFortVal = (String)cb.getSelectedItem();
            }
        });
        environementFortEl.setBounds(210, 220, 100, 30);
        this.creerBete.setBounds(150, 270, 100, 30);
        this.creerBete.addActionListener(new Creer());
        panel.add(sexe);
        panel.add(sexeBete);
        panel.add(energie);
        panel.add(energieNb);
        panel.add(attaque);
        panel.add(attaqueNb);
        panel.add(defense);
        panel.add(defenseNb);
        panel.add(defenseSpe);
        panel.add(defenseSpeEl);
        panel.add(environementFort);
        panel.add(environementFortEl);
        panel.add(this.creerBete);
        this.add(panel);
    }

    public int trouverIdNouvelleBete() {
        int id = this.grille.getNbBeteDepuisLeDebut() + 1;
        this.grille.setNbBeteDepuisLeDebut(id);
        return id;
    }

    public class Creer
    implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            AddBeast.this.idNouvelleBete = AddBeast.this.trouverIdNouvelleBete();
            String sexe = AddBeast.this.sexeBeteType;
            CreerAttaque ca = new CreerAttaque();
            Attaque attaque = ca.creerAttaque(AddBeast.this.niveauAttaqueNb);
            CreerDefense cd = new CreerDefense();
            Defense defense = cd.creerDefense(AddBeast.this.niveauDefenseNb);
            CreerElement elt = new CreerElement();
            Element defenseSpecial = elt.creerElement(AddBeast.this.defenseSpeNb);
            int positionIGrille = AddBeast.this.i;
            int positionJGrille = AddBeast.this.j;
            EnvironnementFort environementFort = new EnvironnementFort(AddBeast.this.environnementFortVal);
            String journale = "";
            Journal journal = new Journal(journale);
            int coordX = AddBeast.this.caseDeLaBete.getX();
            int coordY = AddBeast.this.caseDeLaBete.getY();
            Bete beteCree = new Bete(AddBeast.this.idNouvelleBete, sexe, attaque, defense, defenseSpecial, environementFort, new Energie(), coordX, coordY, positionIGrille, positionJGrille, journal);
            beteCree.setHeureNaissance(AddBeast.this.chronometer);
            beteCree.getEnergie().setEnergie(AddBeast.this.energieBeteNb);
            logger.info((Object)(";" + beteCree.getId() + ";" + "Creation;" + beteCree.getSexe() + ";Utilisateur;"));
            AddBeast.this.caseDeLaBete.addBeteCase(beteCree);
            AddBeast.this.grille.getEnsembleDesBete().add(beteCree);
            AddBeast.this.output.repaint();
            AddBeast.this.setVisible(false);
        }
    }
}
*/
