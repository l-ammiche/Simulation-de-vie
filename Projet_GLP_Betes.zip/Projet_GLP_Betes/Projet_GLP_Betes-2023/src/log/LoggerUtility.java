package log;

//cette classe est un test LOG4J

/*
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoggerUtility {
    private static final String TEXT_LOG_CONFIG = "C:\\Users\\33665\\OneDrive\\Bureau\\Projet_betes_test_1231\\resources\\log\\log4j-text.properties";
    private static final String HTML_LOG_CONFIG = "C:\\Users\\33665\\OneDrive\\Bureau\\Projet_betes_test_1231\\resources\\log\\log4j-text.properties";

    public static Logger getLogger(Class<?> logClass, String logFileType) {
        if (logFileType.equals("text")) {
            PropertyConfigurator.configure((String)TEXT_LOG_CONFIG);
        } else if (logFileType.equals("html")) {
            PropertyConfigurator.configure((String)HTML_LOG_CONFIG);
        } else {
            throw new IllegalArgumentException("Unknown log file type !");
        }
        String className = logClass.getName();
        return Logger.getLogger((String)className);
    }
}
*/

