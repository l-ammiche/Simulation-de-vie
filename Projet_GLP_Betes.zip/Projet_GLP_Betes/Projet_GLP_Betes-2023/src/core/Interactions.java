package core;

import gui.*;
import util.Randomizer;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import data.*;

public class Interactions {
	
	//toutes les interactions entre les insectes seont représentées dans cette classe
	
	private int firstBeast;
	private int secondBeast;
	private ArrayList<BeastPanel> beastsPanel;
	private int copulationTurn;
	
	public Interactions() {
		copulationTurn = 0;
	}
	

	
	public int analyseTile(TilePanel tilePanel, ArrayList<BeastPanel> beastPanel) {
		
		beastsPanel = beastPanel;
		int beastPerTile = 0;
		int tileAbsciss = tilePanel.getTile().getAbsciss();
		int tileOrdinate = tilePanel.getTile().getOrdinate();
		int absciss = 0;
		int ordinate = 0;
		
		for(int i=0;i<Map_Settings.nbBeasts;i++) {
			
			if(beastPanel.get(i).getBeast().getStats().getStamina()<=0) {
				beastPanel.get(i).getBeast().setDeath(true);
			}
			absciss = beastPanel.get(i).getBeast().getAbsciss();
			ordinate = beastPanel.get(i).getBeast().getOrdinate();
			if(tileAbsciss==absciss && tileOrdinate==ordinate) {
				
				if(beastPerTile==0) {
					
					tilePanel.setFirst(i);
					firstBeast = i;
				}
				else if(beastPerTile==1) {
					tilePanel.setSecond(i);
					secondBeast = i;
				}
				beastPerTile++;
			}
		}
		if(beastPerTile>=2) {
			
			for(int i=0;i<Map_Settings.nbBeasts;i++) {
				
				absciss = beastPanel.get(i).getBeast().getAbsciss();
				ordinate = beastPanel.get(i).getBeast().getOrdinate();
				if(tileAbsciss==absciss && tileOrdinate==ordinate) {
					beastPanel.get(i).getBeast().setMove(false);
				}
			}
			if(!tilePanel.getTile().isFighting() && !tilePanel.getTile().isCopulating()) {
				
				int fightChances = 0;
				if(beastPanel.get(firstBeast).getBeast().getSexe().equals(beastPanel.get(secondBeast).getBeast().getSexe())) {
					fightChances = 100;
				}
				else {
					if(beastPanel.get(firstBeast).getBeast().getBiome().equals(beastPanel.get(secondBeast).getBeast().getBiome())) {
						fightChances = 40;
					}
					else {fightChances = 60;}
				}
				
				int chances = Map_Settings.generateRand(1,100);
				if(chances<=fightChances) {
					tilePanel.getTile().setFight(true);
					beastPanel.get(firstBeast).getBeast().setFight(true);
					beastPanel.get(secondBeast).getBeast().setFight(true);
				}
				
				else {
					
					tilePanel.getTile().setCopulation(true);
					beastPanel.get(firstBeast).getBeast().setCopulation(true);
					beastPanel.get(secondBeast).getBeast().setCopulation(true);
				}
			}
			else {
				
				
				if(tilePanel.getTile().isFighting()) turnFight(beastPanel.get(firstBeast).getBeast(), beastPanel.get(secondBeast).getBeast(), tilePanel.getTile());
				

				
				else if(tilePanel.getTile().isCopulating()) {
					launchCopulation(beastPanel.get(firstBeast).getBeast(), beastPanel.get(secondBeast).getBeast(), tilePanel.getTile());
				}
			}
			
			
		}
		
		beastPanel = beastsPanel;
		return beastPerTile;
		
	}
	
	public void launchCopulation(Beast beastOne, Beast beastTwo, Tile tile) {

	    // Vérifier la stamina des parents
	    if (beastOne.getStamina() <= 0 || beastTwo.getStamina() <= 0) {
	        // Si la stamina de l'un des parents atteint 0, ils meurent et sont supprimés de la map
	        if (beastOne.getStamina() <= 0) {
	            removeBeastFromMap(beastOne);
	        }
	        if (beastTwo.getStamina() <= 0) {
	            removeBeastFromMap(beastTwo);
	        }
	        copulationTurn = 0;
	        tile.setCopulation(false);
	        return;
	    }

	    // fight
	    beastOne.removeStamina(6);
	    beastTwo.removeStamina(6);
	    boolean mutating = Map_Settings.randomBoolean();
	    Beast babyBeast = null;
	    if (copulationTurn == 0) {
	        if (mutating) {
	            // Le bébé hérite des caractéristiques des deux parents
	            babyBeast = new Beast(beastOne, beastTwo);
	        } else {
	            // Le bébé est créé avec la position et le biome du premier parent
	            babyBeast = new Beast(beastOne.getLocation(), tile.getBiome());
	        }
	        babyBeast.setNumber(Map_Settings.nbBeasts);
	        BeastPanel babyBeastPanel = new BeastPanel(babyBeast);
	        babyBeastPanel.setBeastImage();
	        beastsPanel.add(Map_Settings.nbBeasts, babyBeastPanel);
	        Map_Settings.incrementNbBeasts();
	        copulationTurn++;
	    } else {
	    	
	        copulationTurn = 0;
	        tile.setCopulation(false);
	        removeBeastFromMap(beastOne);
	        removeBeastFromMap(beastTwo);
	        System.out.println("Copulation Ended\n");
	    }
	}

	private void removeBeastFromMap(Beast beast) {
	    // Supprimer la bête de la map
	    // code pour supprimer la bête de la map
	}

	
	public void turnFight(Beast beastOne, Beast beastTwo, Tile tile) {
	    Biome tileBiome = new Biome(tile.getBiome().getBiomeType());
	    Attack attackOne = beastOne.getStats().getAttack();
	    Defense defenseOne = beastOne.getStats().getDefense();
	    Defense defenseTwo = beastTwo.getStats().getDefense();
	    Attack attackTwo = beastTwo.getStats().getAttack();
	    

	    if (Map_Settings.SIMULATION_TURNS % 2 == 0) {
	        beastOne.removeStamina(5);
	        if (tileBiome.equals(beastOne.getBiome())) {
	            // Higher chance of landing a critical hit when attacking in own biome
	            boolean isCriticalHit = Map_Settings.randomChance(0.3);
	            beastTwo.removeLive(attackOne, defenseTwo, true, false, isCriticalHit);
	        } else {
	        	
	            if (tileBiome.equals(beastTwo.getBiome())) {
	                // Higher chance of causing a status effect when attacking in opponent's biome
	                boolean statusEffectApplied = Map_Settings.randomChance(0.5);
	                beastTwo.removeLive(attackOne, defenseTwo, false, true, false, statusEffectApplied);
	            } else {
	            	
	                // Normal attack
	                beastTwo.removeLive(attackOne, defenseOne, false, false);
	            }
	        }
	    } else if (Map_Settings.SIMULATION_TURNS % 2 == 1) {

	    	beastTwo.removeStamina(5);
	    	
	        if (tileBiome.equals(beastTwo.getBiome())) {
	        	
	            // Higher chance of landing a critical hit when attacking in own biome
	            boolean isCriticalHit = Map_Settings.randomChance(0.3);
	            beastOne.removeLive(attackTwo, defenseOne, true, false, isCriticalHit);
	        } else {
	        	
	            if (tileBiome.equals(beastTwo.getBiome())) {
	                // Higher chance of causing a status effect when attacking in opponent's biome
	                boolean statusEffectApplied = Map_Settings.randomChance(0.5);
	                beastOne.removeLive(attackTwo, defenseOne, false, true, false, statusEffectApplied);
	            } else {
	            	
	                // Normal attack
	                beastOne.removeLive(attackOne, defenseOne, false, false);
	            }
	        }
	    }

	    if (beastOne.getStats().getlivePoints() <= 0 || beastTwo.getStats().getlivePoints() <= 0) {
	        int maxFightDuration = 10; // Maximum number of turns for a fight
	        int currentFightDuration = tile.getFightDuration();
	        tile.setFightDuration(currentFightDuration + 1);

	        if (beastOne.getStats().getlivePoints() <= 0) {
	            beastOne.setDeath(true);
	            beastTwo.setFight(false);
	            beastTwo.setMove(true);
	            removeBeastFromMap(beastOne);
	        }
	        if (beastTwo.getStats().getlivePoints() <= 0) {
	            beastTwo.setDeath(true);
	            beastOne.setFight(false);
	            beastOne.setMove(true);
	            removeBeastFromMap(beastTwo);
	        }

	        // Check fight duration
	        if (currentFightDuration + 1 >= maxFightDuration) {
	            tile.setFight(false);
	            System.out.println("Fight ended - Maximum duration reached\n");
	        } else {
	            System.out.println("Fight ended\n");
	        }
	    }
	}


	
	public void eatFood(Beast beast, Food food, Tile tile) {
	    Stats beastStats = beast.getStats();
	    int foodRemove = 0;

	    if (beastStats.getlivePoints() < beastStats.getMaxLife()) {
	        // Calculate the amount of food needed to reach maximum health
	        foodRemove = (int) (beastStats.getMaxLife() - beastStats.getlivePoints());

	        // Check if there is enough food available
	        if (food.getFoodValue() >= foodRemove) {
	            food.removeFoodValue(foodRemove);
	            beast.getStats().setlivePoints(beastStats.getMaxLife());
	        } else {
	            // If there is not enough food, consume all available food
	            foodRemove = food.getFoodValue();
	            food.removeFoodValue(foodRemove);
	            beast.getStats().setlivePoints(beastStats.getlivePoints() + foodRemove);
	        }

	        // Restore stamina to maximum
	        beast.getStats().setStamina(beastStats.getMaxStamina());
	    } else {
	        if (beastStats.getStamina() < beastStats.getMaxStamina()) {
	            // Calculate the amount of food needed to reach maximum stamina
	            foodRemove = (int) (beastStats.getMaxStamina() - beastStats.getStamina());

	            // Check if there is enough food available
	            if (food.getFoodValue() >= foodRemove) {
	                food.removeFoodValue(foodRemove);
	                beast.getStats().setStamina(beastStats.getMaxStamina());
	            } else {
	                // If there is not enough food, consume all available food
	                foodRemove = food.getFoodValue();
	                food.removeFoodValue(foodRemove);
	                beast.getStats().setStamina(beastStats.getStamina() + foodRemove);
	            }
	        }
	    }

	    // Update the last feeding time of the beast
	    beast.setLastFeedingTime(System.currentTimeMillis());

	    if (food.getFoodValue() <= 0) {
	        tile.setFood(false);
	    }

	    
	    PrintWriter writer = null;
		try {
			writer = new PrintWriter(new FileWriter("assets/log/bete-log.txt", true));
			  char[] message = null;
				writer.println("Beast " + beast.getNumber() + " a mangé à: " + beast.getLastFeedingTime());
				writer.println("Beast " + beast.getNumber() + " a combattu à: " + beast.isDead());

		        writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	
	
	
	
	
	
	
	
	


}
