package core;

public class Fighting {

}
