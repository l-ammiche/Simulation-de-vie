package core;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.Iterator;

import javax.swing.JComponent;

import data.*;
import gui.*;

public class MapBuilder{
	
	MapPanel panel;
	Image tile = null;
	int biomeNumber = Map_Settings.generateRand(1,1);
	public MapBuilder(MapPanel mapPanel) {
		panel = mapPanel;
	}
	public MapBuilder() {
		
	}
	
	//random biomes
	public MapPanel setRandomMap(MapPanel mapPanel) {
		if(mapPanel == null) {
			mapPanel = new MapPanel();	
		}
		for(int i=0;i<Map_Settings.MAP_WIDTH;i++) {
			for(int j=0;j<Map_Settings.MAP_LENGTH;j++) {
				int biomeNumber = Map_Settings.generateRand(1, 4); // Génère un nombre aléatoire entre 1 et 4

				if (biomeNumber == 1) {
				    biomeNumber = Map_Settings.generateRand(1, 1);
				} else if (biomeNumber == 2) {
				    biomeNumber = Map_Settings.generateRand(2, 2);
				} else if (biomeNumber == 3) {
				    biomeNumber = Map_Settings.generateRand(3, 3);
				} else if (biomeNumber == 4) {
				    biomeNumber = Map_Settings.generateRand(4, 4);
				}
				
				int chances = 29;
				int obstacle = Map_Settings.generateRand(1, chances);
				mapPanel.setTilePanel(i, j, biomeNumber);
				mapPanel.getTile(i, j).setLocation(new Location(i, j));
				
				if (obstacle <=chances && obstacle> 29*chances/30) {
					mapPanel.getTile(i, j).setFood(true);
					Food food = new Food(i, j);
					mapPanel.getFoodPanel().add(food);
				} else if(obstacle<=29*chances/30 && obstacle> 24*chances/30) {
					mapPanel.getTile(i,  j).setObstacle(true);
				}
			}
		}
		return mapPanel;
	}
	
	
	public MapPanel setTileImages(MapPanel mapPanel) {
	    // Parcourt toutes les cases de la carte en utilisant les constantes MAP_WIDTH et MAP_LENGTH de la classe Map_Settings
	    for (int i = 0; i < Map_Settings.MAP_WIDTH; i++) {
	        for (int j = 0; j < Map_Settings.MAP_LENGTH; j++) {
	            // Définit l'image de la tuile dans le TilePanel correspondant
	            mapPanel.getTilePanel(i, j).setTileImage();
	        }
	    }
	    
	    // Retourne le MapPanel mis à jour avec les images des tuiles
	    return mapPanel;
	}


	public MapPanel setRandomBeasts(MapPanel mapPanel) {
		if(mapPanel == null) {
			this.setRandomMap(mapPanel);
		}	
		for(int i=0;i<Map_Settings.nbBeasts;i++) {
			int A = i*100/Map_Settings.BEAST_PERCENT;
			int tile = Map_Settings.generateRand(A,  A+(100/Map_Settings.BEAST_PERCENT));
			int absciss = tile/Map_Settings.MAP_WIDTH;
			int ordinate = tile%Map_Settings.MAP_LENGTH;
			Location loc = new Location(absciss, ordinate);
			Biome tileBiome = mapPanel.getTile(absciss, ordinate).getBiome();
			BeastPanel beastPanel = new BeastPanel(new Beast(loc, tileBiome));
			beastPanel.getBeast().setNumber(i);
			mapPanel.getBeastPanel().add(beastPanel);
		}
		return mapPanel;
	}
	public MapPanel setBeastImages(MapPanel mapPanel) {
		if(mapPanel == null) {
			this.setRandomBeasts(mapPanel);
		}
		for(int i=0;i<Map_Settings.MAP_WIDTH;i++) {
			for(int j=0;j<Map_Settings.MAP_LENGTH;j++) {
				for(int h=0;h<Map_Settings.nbBeasts;h++) {
					int absciss = mapPanel.getBeast(h).getAbsciss();
					int ordinate = mapPanel.getBeast(h).getOrdinate();
					if(absciss == mapPanel.getTile(i, j).getAbsciss() && ordinate == mapPanel.getTile(i, j).getOrdinate()) {
						Image beastImage = mapPanel.getBeastPanel().get(h).getBeastImage();
						mapPanel.getTilePanel(i, j).setBeastImage(beastImage);
					}
				}
			}
		}
		return mapPanel;
	}
}

	
