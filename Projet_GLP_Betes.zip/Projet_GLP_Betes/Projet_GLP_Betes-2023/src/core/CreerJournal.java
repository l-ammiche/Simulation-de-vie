package core;


import data.Beast;
import data.bete.Journal;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CreerJournal {
    protected Beast bete;

    public CreerJournal(Beast bete) {
        this.bete = bete;
        this.creerJournal(bete);
    }

    public void creerJournal(Beast bete) {
        String info = "";
        String newLine = System.getProperty("line.separator");
        try {
            String ligne;
            BufferedReader br = new BufferedReader(new FileReader("assets/log/bete-log.txt"));
            while ((ligne = br.readLine()) != null) {
                String[] res = ligne.split(";");
                if (!res[1].equals(Integer.toString(bete.getId()))) continue;
                System.out.println(res[2]);
                info = String.valueOf(info) + res[2];
                info = String.valueOf(info) + newLine;
            }
            br.close();
        }
        catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
        }
        Journal journal = new Journal(info);
        bete.setJournal(journal);
    }
}

