package data;

import java.util.Random;


public class Food {
	
	private int maxFoodValue;
	private int foodValue;
	private Location location;
	
		

	public Food(int i, int j) {
	    maxFoodValue = 30;
	    location = new Location(i, j);

	    // Générer une valeur aléatoire pour la nourriture entre 0 et maxFoodValue
	    Random random = new Random();
	    foodValue = random.nextInt(maxFoodValue + 1); // +1 pour inclure également maxFoodValue
	}

	public int getFoodValue() {
		return foodValue;
	}
	public int getMaxFoodValue() {
		return maxFoodValue;
	}
	
	public void setFoodValue(int FoodValue) {
		foodValue = FoodValue;
	}
	public void setMaxFoodValue(int FoodValue) {
		maxFoodValue = FoodValue;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}
	
	public void removeFoodValue(int number) {
		foodValue-=number;
		if(foodValue<0) location = new Location(-1,-1);
	}
	
	

}