/*
 * Decompiled with CFR 0.151.
 */
package data.bete;

public class EnvironnementFort {
    private String environnementFort;

    public EnvironnementFort(String environnementFort) {
        this.environnementFort = environnementFort;
    }

    public String getEnvironnementFort() {
        return this.environnementFort;
    }

    public void setEnvironnementFort(String environnementFort) {
        this.environnementFort = environnementFort;
    }
}

