package data;

public class Attack {
    private double baseAttack;
    private double minAttack;
    private double maxAttack;

    public Attack() {
        baseAttack = 25;
        minAttack = 15;
        maxAttack = 35;
    }

    public Attack(double baseAttack, double minAttack, double maxAttack) {
        this.baseAttack = baseAttack;
        this.minAttack = minAttack;
        this.maxAttack = maxAttack;
    }

    public double getBaseAttack() {
        return baseAttack;
    }

    public void setBaseAttack(double attack) {
        baseAttack = attack;
    }

    public double getMinAttack() {
        return minAttack;
    }

    public void setMinAttack(double attack) {
        minAttack = attack;
    }

    public double getMaxAttack() {
        return maxAttack;
    }

    public void setMaxAttack(double attack) {
        maxAttack = attack;
    }

    public double calculateAttack() {
        double randomMultiplier = Math.random(); // Random number between 0 and 1
        double attackRange = maxAttack - minAttack;
        double additionalAttack = attackRange * randomMultiplier;
        double finalAttack = baseAttack + additionalAttack;
        return finalAttack;
    }

    public String toString() {
        return "Base atk: " + baseAttack + " Min atk: " + minAttack + " Max atk: " + maxAttack;
    }
}
