package data;

import gui.Map_Settings;

public class Location {
	
	private int absciss;
	private int ordinate;
	
	public Location(int x, int y) {
		setLocation(x, y);
	}
	
	public Location(int random) {
		setRandomLocation(random);
	}
	
	public void setAbsciss(int x) {
		absciss = Math.max(0, Math.min(x, Map_Settings.MAP_WIDTH - 1));
	}
	
	public int getAbsciss() {
		return absciss;
	}
	
	public void setOrdinate(int y) {
		ordinate = Math.max(0, Math.min(y, Map_Settings.MAP_LENGTH - 1));
	}
	
	public int getOrdinate() {
		return ordinate;
	}
	
	public void setLocation(int x, int y) {
		setAbsciss(x);
		setOrdinate(y);
	}
	
	public void setRandomLocation(int random) {
		int x = random % Map_Settings.MAP_WIDTH;
		int y = random % Map_Settings.MAP_LENGTH;
		setLocation(x, y);
	}
	
	public String toString() {
		return "A: " + absciss + " O: " + ordinate + "\n";
	}
	
	public boolean isValideLoc() {
		return absciss >= 0 && absciss < Map_Settings.MAP_WIDTH && ordinate >= 0 && ordinate < Map_Settings.MAP_LENGTH;
	}
}
