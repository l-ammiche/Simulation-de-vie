package data;

public class Defense {
	
	private double baseDefense;
	private double minDefense;
	private double maxDefense;
	

	
	
	public Defense() {
		baseDefense = 12;
		minDefense = 6;
		maxDefense = 20;
	}
	
	public Defense(double baseDefense, double minDefense, double maxDefense) {
		this.baseDefense = baseDefense;
		this.minDefense = minDefense;
		this.maxDefense = maxDefense;
	}
	
	public double getBaseDefense() {
		return baseDefense;
	}
	
	public void setBaseDefense(double defense) {
		baseDefense = defense;
	}
	
	public double getMinDefense() {
		return minDefense;
	}
	
	public void setMinDefense(double defense) {
		minDefense = defense;
	}
	
	public double getMaxDefense() {
		return maxDefense;
	}
	
	public void setMaxDefense(double defense) {
		maxDefense = defense;
	}
	
	public double calculateDefense() {
		double randomMultiplier = Math.random(); // Random number between 0 and 1
		double defenseRange = maxDefense - minDefense;
		double additionalDefense = defenseRange * randomMultiplier;
		double finalDefense = baseDefense + additionalDefense;
		return finalDefense;
	}
	
	public String toString() {
		return "Base def: " + baseDefense + " Min def: " + minDefense + " Max def: " + maxDefense;
	}
}
