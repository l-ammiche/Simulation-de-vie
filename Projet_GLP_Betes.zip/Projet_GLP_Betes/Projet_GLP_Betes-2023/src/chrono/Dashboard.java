/*
 * Decompiled with CFR 0.151.
 */
package chrono;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Dashboard
extends JPanel {
    private static final long serialVersionUID = 1L;
    private int hourPositionX = 400;
    private int hourPositionY = 50;
    private int minutePositionX = 400;
    private int minutePositionY = 50;
    private int secondPositionX = 400;
    private int secondPositionY = 50;

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLUE);
        g.drawOval(300, 50, 200, 200);
        g.drawLine(400, 150, this.hourPositionX + 250, this.hourPositionY);
        g.setColor(Color.RED);
        g.drawLine(400, 150, this.minutePositionX, this.minutePositionY);
        g.setColor(Color.BLACK);
        g.drawLine(400, 150, this.secondPositionX - 250, this.secondPositionY);
    }

    public void setHourPositionX(int hourPositionX) {
        this.hourPositionX = hourPositionX;
    }

    public void setHourPositionY(int hourPositionY) {
        this.hourPositionY = hourPositionY;
    }

    public void setMinutePositionX(int minutePositionX) {
        this.minutePositionX = minutePositionX;
    }

    public void setMinutePositionY(int minutePositionY) {
        this.minutePositionY = minutePositionY;
    }

    public void setSecondPositionX(int secondPositionX) {
        this.secondPositionX = secondPositionX;
    }

    public void setSecondPositionY(int secondPositionY) {
        this.secondPositionY = secondPositionY;
    }
}

