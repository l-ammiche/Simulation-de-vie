/*
 * Decompiled with CFR 0.151.
 */
package chrono;

import chrono.CyclicCounter;

public class Chronometer {
    private CyclicCounter hour = new CyclicCounter(0, 500, 0);
    private CyclicCounter minute = new CyclicCounter(0, 12, 0);
    private CyclicCounter second = new CyclicCounter(0, 31, 0);

    public void increment() {
        this.second.increment();
        if (this.second.getValue() == 0) {
            this.minute.increment();
            if (this.minute.getValue() == 0) {
                this.hour.increment();
            }
        }
    }

    public void decrement() {
        this.second.decrement();
        if (this.second.getValue() == 59) {
            this.minute.decrement();
            if (this.minute.getValue() == 59) {
                this.hour.decrement();
            }
        }
    }

    public CyclicCounter getHour() {
        return this.hour;
    }

    public CyclicCounter getMinute() {
        return this.minute;
    }

    public CyclicCounter getSecond() {
        return this.second;
    }

    public String toString() {
        return String.valueOf(this.hour.toString()) + " : " + this.minute.toString() + " : " + this.second.toString();
    }

    public static String transform(int value) {
        String result = "";
        result = value < 10 ? "0" + value : String.valueOf(value);
        return result;
    }

    public void init() {
        this.hour.setValue(0);
        this.minute.setValue(0);
        this.second.setValue(0);
    }
}

