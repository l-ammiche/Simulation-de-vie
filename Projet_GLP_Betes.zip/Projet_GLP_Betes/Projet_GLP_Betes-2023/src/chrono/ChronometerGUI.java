/*
 * Decompiled with CFR 0.151.
 */
package chrono;

import chrono.Chronometer;
import chrono.CyclicCounter;
import chrono.Dashboard;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ChronometerGUI
extends JFrame
implements Runnable {
    private static final Dimension IDEAL_MAIN_DIMENSION = new Dimension(800, 400);
    private static final Dimension IDEAL_DASHBOARD_DIMENSION = new Dimension(800, 300);
    private static Font font = new Font("Monospaced", 1, 20);
    private static final int CHRONO_SPEED = 1000;
    private static final long serialVersionUID = 1L;
    private Chronometer chronometer = new Chronometer();
    private JButton startButton = new JButton(" Start ");
    private JButton clearButton = new JButton(" Clear ");
    private JLabel hourLabel = new JLabel("Hour:");
    private JLabel minuteLabel = new JLabel("Minute:");
    private JLabel secondLabel = new JLabel("Second:");
    private JLabel hourValue = new JLabel("");
    private JLabel minuteValue = new JLabel("");
    private JLabel secondValue = new JLabel("");
    private JPanel control = new JPanel();
    private Dashboard dashboard = new Dashboard();
    private ChronometerGUI instance = this;
    private boolean stop = true;

    public ChronometerGUI(String title) {
        super(title);
        this.init();
    }

    private void init() {
        this.updateValues();
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new BorderLayout());
        this.control.setLayout(new FlowLayout(1));
        this.hourLabel.setFont(font);
        this.control.add(this.hourLabel);
        this.hourValue.setFont(font);
        this.control.add(this.hourValue);
        this.minuteLabel.setFont(font);
        this.control.add(this.minuteLabel);
        this.minuteValue.setFont(font);
        this.control.add(this.minuteValue);
        this.secondLabel.setFont(font);
        this.control.add(this.secondLabel);
        this.secondValue.setFont(font);
        this.control.add(this.secondValue);
        this.startButton.setFont(font);
        this.startButton.addActionListener(new StartStopAction());
        this.control.add(this.startButton);
        this.clearButton.setFont(font);
        this.clearButton.addActionListener(new ClearAction());
        this.control.add(this.clearButton);
        contentPane.add("North", this.control);
        this.dashboard.setPreferredSize(IDEAL_DASHBOARD_DIMENSION);
        contentPane.add("South", this.dashboard);
        this.setDefaultCloseOperation(3);
        this.pack();
        this.setVisible(true);
        this.setPreferredSize(IDEAL_MAIN_DIMENSION);
        this.setResizable(false);
    }

    private void updateValues() {
        CyclicCounter hour = this.chronometer.getHour();
        this.hourValue.setText(String.valueOf(hour.toString()) + " ");
        CyclicCounter minute = this.chronometer.getMinute();
        this.minuteValue.setText(String.valueOf(minute.toString()) + " ");
        CyclicCounter second = this.chronometer.getSecond();
        this.secondValue.setText(String.valueOf(second.toString()) + " ");
        double hourRadian = this.calculateRadian(hour.getValue());
        this.dashboard.setHourPositionX((int)(150.0 + 100.0 * Math.cos(hourRadian)));
        this.dashboard.setHourPositionY((int)(150.0 - 100.0 * Math.sin(hourRadian)));
        double minuteRadian = this.calculateRadian(minute.getValue());
        this.dashboard.setMinutePositionX((int)(400.0 + 100.0 * Math.cos(minuteRadian)));
        this.dashboard.setMinutePositionY((int)(150.0 - 100.0 * Math.sin(minuteRadian)));
        double secondRadian = this.calculateRadian(second.getValue());
        this.dashboard.setSecondPositionX((int)(650.0 + 100.0 * Math.cos(secondRadian)));
        this.dashboard.setSecondPositionY((int)(150.0 - 100.0 * Math.sin(secondRadian)));
        this.dashboard.repaint();
    }

    private double calculateRadian(float value) {
        return (double)(-value / 30.0f) * Math.PI + 1.5707963267948966;
    }

    @Override
    public void run() {
        while (!this.stop) {
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
            this.chronometer.increment();
            this.updateValues();
        }
    }

    public static void main(String[] args) {
        new ChronometerGUI("Chronometer");
    }

    private class ClearAction
    implements ActionListener {
        private ClearAction() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            ChronometerGUI.this.stop = true;
            ChronometerGUI.this.startButton.setText(" Start ");
            ChronometerGUI.this.chronometer.init();
            ChronometerGUI.this.updateValues();
        }
    }

    private class StartStopAction
    implements ActionListener {
        private StartStopAction() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (!ChronometerGUI.this.stop) {
                ChronometerGUI.this.stop = true;
                ChronometerGUI.this.startButton.setText(" Start ");
            } else {
                ChronometerGUI.this.stop = false;
                ChronometerGUI.this.startButton.setText(" Pause ");
                Thread chronoThread = new Thread(ChronometerGUI.this.instance);
                chronoThread.start();
            }
        }
    }
}

