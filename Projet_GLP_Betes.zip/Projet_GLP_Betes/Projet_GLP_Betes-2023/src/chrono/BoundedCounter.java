/*
 * Decompiled with CFR 0.151.
 */
package chrono;

import chrono.Counter;

public class BoundedCounter
extends Counter {
    private int max;
    private int min;

    public BoundedCounter(int value, int max, int min) {
        super(value);
        this.max = max;
        this.min = min;
    }

    @Override
    public void decrement() {
        if (this.getValue() > this.min) {
            super.decrement();
        }
    }

    @Override
    public void increment() {
        if (this.getValue() < this.max) {
            super.increment();
        }
    }

    public int getMax() {
        return this.max;
    }

    public int getMin() {
        return this.min;
    }
}

