/*
 * Decompiled with CFR 0.151.
 */
package chrono;

import chrono.BoundedCounter;
import chrono.Chronometer;

public class CyclicCounter
extends BoundedCounter {
    public CyclicCounter(int value, int max, int min) {
        super(value, max, min);
    }

    @Override
    public void decrement() {
        if (this.getValue() > this.getMin()) {
            super.decrement();
        } else {
            this.setValue(this.getMax());
        }
    }

    @Override
    public void increment() {
        if (this.getValue() < this.getMax()) {
            super.increment();
        } else {
            this.setValue(this.getMin());
        }
    }

    public String toString() {
        return Chronometer.transform(this.getValue());
    }
}

